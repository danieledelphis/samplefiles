# Esercizio 3 — Profiling Python

## Obiettivo

Capire **dove** un programma Python consuma tempo, usando `cProfile`.

Abbiamo due funzioni che ordinano `strings.txt` in modo case‑insensitive:

| Funzione | Algoritmo | Complessità |
|----------|-----------|-------------|
| `bubble_sort()` | Bubble sort | O(n²) |
| `python_sort()` | `sorted()` built‑in | O(n log n) |

Il profiler ci mostrerà la differenza senza doverla intuire dal codice.

---

## Step 1 — Generare il file di input

```bash
python3 generate.py
```

Crea `strings.txt` con 5000 stringhe casuali.

---

## Step 2 — Eseguire (senza profiler)

```bash
python3 sort_compare.py
```

---

## Step 3 — Profilare

```bash
./profile.sh
```

Oppure manualmente:

```bash
python3 -m cProfile -s cumulative sort_compare.py
```

Il profiler mostra **ogni funzione** chiamata, quante volte, e quanto tempo ha consumato.

---

## Step 4 — Leggere l'output

Guardate l'output del profiler e rispondete:

- Quale funzione consuma più tempo?
- Quante volte viene chiamata `.lower()`? Perché così tante?
- Quanto tempo impiega `python_sort()` in confronto?

---

## Step 5 — Bonus: visualizzazione con snakeviz

```bash
pip install snakeviz
./profile.sh              # genera sort.prof
snakeviz sort.prof        # apre un grafico interattivo nel browser
```

---

