#!/usr/bin/env python3
"""Confronto tra due algoritmi di ordinamento.
Legge strings.txt, lo ordina con:
  a) bubble_sort  — algoritmo O(n²), volutamente inefficiente
  b) sorted()     — Timsort O(n log n), built-in di Python

Scrive i risultati su file-ordered-a.txt e file-ordered-b.txt.
I due file di output devono essere identici: entrambi ordinati
case‑insensitive.

Eseguire con il profiler:
  python -m cProfile sort_compare.py             # output a terminale
  python -m cProfile -o sort.prof sort_compare.py # salva su file
  snakeviz sort.prof                               # grafico interattivo
"""

import time

INPUT_FILE = "strings.txt"
OUTPUT_A   = "file-ordered-a.txt"
OUTPUT_B   = "file-ordered-b.txt"


# - Slow sort: bubble sort case‑insensitive -

def bubble_sort(lines):
    arr = lines[:]  # non modificare l'originale
    n = len(arr)
    for i in range(n):
        for j in range(n - i - 1):
            if arr[j].lower() > arr[j + 1].lower():
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
    return arr


# - Sensato sort: sorted() built‑in -

def python_sort(lines):
    return sorted(lines, key=str.lower)


# - Main -

def main():
    # Leggi il file
    with open(INPUT_FILE) as f:
        lines = [line.rstrip('\n') for line in f]
    print(f"Lette {len(lines)} righe da {INPUT_FILE}")

    # Bubble sort
    t0 = time.perf_counter()
    result_a = bubble_sort(lines)
    t1 = time.perf_counter()

    with open(OUTPUT_A, 'w') as f:
        f.write('\n'.join(result_a) + '\n')
    #print(f"bubble_sort:  {t1 - t0:.3f} s  →  {OUTPUT_A}")
    print(f"bubble_sort: {OUTPUT_A}")

    # Built‑in sort
    t0 = time.perf_counter()
    result_b = python_sort(lines)
    t1 = time.perf_counter()

    with open(OUTPUT_B, 'w') as f:
        f.write('\n'.join(result_b) + '\n')
    #print(f"python_sort:  {t1 - t0:.6f} s  →  {OUTPUT_B}")
    print(f"python_sort: {OUTPUT_B}")

    # Verifica che i risultati coincidano
    assert result_a == result_b, "ERRORE: i due output sono diversi!"
    print("OK: i due file sono identici.")


if __name__ == '__main__':
    main()
