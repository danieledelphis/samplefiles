#!/usr/bin/env python3

import random
import string

N = 5000  # numero di stringhe da generare
OUTPUT = "strings.txt"

def random_string(length=8):
    return ''.join(random.choices(string.ascii_letters + string.digits, k=length))

def main():
    strings = [random_string() for _ in range(N)]
    # Inseriamo qualche duplicato e variante case per rendere il sort interessante
    for i in range(N // 10):
        strings[i * 10] = strings[i * 10].swapcase()
    random.shuffle(strings)

    with open(OUTPUT, 'w') as f:
        f.write('\n'.join(strings) + '\n')

    print(f"Generato {OUTPUT} con {N} stringhe")

if __name__ == '__main__':
    main()
