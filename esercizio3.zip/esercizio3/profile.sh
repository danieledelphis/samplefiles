#!/bin/bash
# Profila sort_compare.py e salva i risultati

set -e

echo "=== Profiling cProfile (solo console) ==="
python3 -m cProfile -s cumulative sort_compare.py

echo ""
echo "=== Salvando su sort.prof ==="
python3 -m cProfile -o sort.prof sort_compare.py
echo "File sort.prof creato."
echo ""
echo "Per visualizzare un grafico interattivo (opzionale):"
echo "  pip install snakeviz"
echo "  snakeviz sort.prof"
