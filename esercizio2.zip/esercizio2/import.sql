-- import.sql — eseguire DOPO schema.sql
-- Importa i 3 CSV nelle tabelle. L'ordine conta:
-- prima fornitori e clienti (non hanno FK), poi fatture (ha FK verso entrambi)
-- Se va in errore: correggere il CSV, TRUNCATE TABLE, riprovare

LOAD DATA INFILE '/csv/fornitori.csv'
  INTO TABLE fornitori
  FIELDS TERMINATED BY ',' ENCLOSED BY '"'
  LINES TERMINATED BY '\n'
  IGNORE 1 ROWS;

LOAD DATA INFILE '/csv/clienti.csv'
  INTO TABLE clienti
  FIELDS TERMINATED BY ',' ENCLOSED BY '"'
  LINES TERMINATED BY '\n'
  IGNORE 1 ROWS;

LOAD DATA INFILE '/csv/fatture.csv'
  INTO TABLE fatture
  FIELDS TERMINATED BY ',' ENCLOSED BY '"'
  LINES TERMINATED BY '\n'
  IGNORE 1 ROWS;
