CREATE TABLE clienti (
    id_cliente INT PRIMARY KEY,
    nome       VARCHAR(100) NOT NULL,
    cognome    VARCHAR(100),
    email      VARCHAR(200),
    telefono   VARCHAR(30),
    citta      VARCHAR(100),
    provincia  CHAR(2)
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE fornitori (
    id_fornitore   INT PRIMARY KEY,
    ragione_sociale VARCHAR(200) NOT NULL,
    partita_iva    VARCHAR(20),
    indirizzo      VARCHAR(200),
    cap            VARCHAR(10),
    citta          VARCHAR(100),
    nazione        VARCHAR(50) DEFAULT 'Italia'
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE fatture (
    id_fattura     INT PRIMARY KEY,
    numero         VARCHAR(20),
    data_emissione DATE NOT NULL,
    data_scadenza  DATE,
    id_cliente     INT NOT NULL,
    id_fornitore   INT NOT NULL,
    imponibile     DECIMAL(12,2),
    iva            DECIMAL(12,2),
    totale         DECIMAL(12,2),
    stato          VARCHAR(50),
    FOREIGN KEY (id_cliente)
      REFERENCES clienti(id_cliente),
    FOREIGN KEY (id_fornitore)
      REFERENCES fornitori(id_fornitore)
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
