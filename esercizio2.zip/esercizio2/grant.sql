-- grant.sql — eseguire UNA VOLTA come root, poi usare mariadb.sh per il resto
-- docker exec -it quickshop mariadb -u root -prootpass quickshop < grant.sql
GRANT FILE ON *.* TO 'quickshop'@'%';
FLUSH PRIVILEGES;
