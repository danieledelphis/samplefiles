-- 1. Conteggio finale
SELECT 'clienti'   AS tab, COUNT(*) FROM clienti
UNION ALL SELECT 'fornitori', COUNT(*) FROM fornitori
UNION ALL SELECT 'fatture',   COUNT(*) FROM fatture;

-- 2. FK orfane (devono restituire 0 righe)
SELECT f.id_fattura, f.id_cliente
FROM fatture f
LEFT JOIN clienti c ON c.id_cliente = f.id_cliente
WHERE c.id_cliente IS NULL;

SELECT f.id_fattura, f.id_fornitore
FROM fatture f
LEFT JOIN fornitori fn ON fn.id_fornitore = f.id_fornitore
WHERE fn.id_fornitore IS NULL;

-- 3. Somma totale fatture
SELECT SUM(imponibile) AS tot_imponibile,
       SUM(iva)       AS tot_iva,
       SUM(totale)    AS tot_fatture
FROM fatture;
