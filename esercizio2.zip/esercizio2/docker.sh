#!/bin/bash
# Avvia QuickShop MariaDB senza docker-compose
# Blocca se il container esiste già

set -e

DIR="$(cd "$(dirname "$0")" && pwd)"

if docker ps -a --format '{{.Names}}' | grep -qx quickshop; then
    echo "Container 'quickshop' già esistente. Rimuovilo con: docker rm -f quickshop"
    exit 1
fi

docker run -d --name quickshop \
  -e MARIADB_ROOT_PASSWORD=rootpass \
  -e MARIADB_USER=quickshop \
  -e MARIADB_PASSWORD=quickshop \
  -e MARIADB_DATABASE=quickshop \
  -p 3306:3306 \
  -v "$DIR/clienti.csv:/csv/clienti.csv:ro" \
  -v "$DIR/fornitori.csv:/csv/fornitori.csv:ro" \
  -v "$DIR/fatture.csv:/csv/fatture.csv:ro" \
  mariadb:11

echo "OK. Connettiti con: docker exec -it quickshop mariadb -u quickshop -pquickshop quickshop"
