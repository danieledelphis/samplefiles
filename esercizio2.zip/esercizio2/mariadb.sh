#!/bin/bash

docker exec -it quickshop mariadb -u quickshop -pquickshop quickshop

